#ifndef __TABULEIRO_H__
#define __TABULEIRO_H__

void tabuleiro_conecta(int, char**);
void tabuleiro_envia(char*);
void tabuleiro_recebe(char*);

#endif
